
public class Hamburguer {
	private double preco;
	private String nome;
	private double custo;
	private String[] ingredientes;
	
	
	public Hamburguer(String nome, double preco, double custo, String[] ingredientes) {
		this.preco = preco;
		this.nome = nome;
		this.custo = custo;
		this.ingredientes = ingredientes;
	}
	
	public double getPreco () {
		return this.preco;
	}
	
	public String getNome() {
		return this.nome;
	}
	
	public double getCusto() {
		return this.custo;
	}
	
	public String getIngrediente() {
		String ingrediente = "";
		for (int i = 0; i < ingredientes.length -1; i++) {
			ingrediente += ingredientes[i];
		}
		return ingrediente;
	}
	
	public double getLucro() {
		return (getPreco() - getCusto());
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
}
