package mvpn;

public class NegociosHamburguers {
	
	private RepositorioHamburguers repositorio;
	
	public void inserir(Hamburguer hamburguer) {
		
		if (this.repositorio.checarHamburguer(hamburguer.getNome())) {
			this.repositorio.inserir(hamburguer);
		}
		else {
			throw new RuntimeException("Ajeitar exce�ao depois");
		}
		
	}
	
	public void remover(String nome) {
		
		if (this.repositorio.checarHamburguer(nome)) {
			this.repositorio.remover(nome);
		}
		else {
			throw new RuntimeException("Ajeitar exce�ao depois");
		}
	}
	
	public void atualizar(String nomeAntigo, String nomeNovo) {
		
		if (this.repositorio.checarHamburguer(nomeAntigo)) {
			
		}
	}
	
	public Hamburguer procurar(Hamburguer hamburguer) {
		return this.repositorio.procurar(hamburguer);
	}
	
	
	
	
	
	
	
	
	
}
