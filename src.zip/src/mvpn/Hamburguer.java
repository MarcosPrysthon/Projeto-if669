package mvpn;

public class Hamburguer {
	private double preco;
	private String nome;
	private double custo;
	private String[] ingredientes;

	public Hamburguer(String nome, double preco, double custo, String[] ingredientes) {
		this.preco = preco;
		this.nome = nome;
		this.custo = custo;
		this.ingredientes = ingredientes;
	}



	public String getNome() {
		return this.nome;
	}

	

	

	

	public void setNome(String nome) {
		this.nome = nome;
	}

	public boolean verificar(String nome) {
		boolean tem = false;
		if (this.nome == nome) {
			tem = true;
		}
		return tem;
	}
	

}
