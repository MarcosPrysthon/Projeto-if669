package mvpn;

public interface RepositorioHamburguers {

	public void inserir (Hamburguer hamburguer);
	
	public void remover (String nome);
	
	public Hamburguer procurar(Hamburguer hamburguer);
	
	public void atualizar(String nomeAntigo, String nomeNovo);
	
	public boolean checarHamburguer (String nome);
}
	
