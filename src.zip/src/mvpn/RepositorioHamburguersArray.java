package mvpn;

public class RepositorioHamburguersArray implements RepositorioHamburguers {
	private Hamburguer[] repositorio = new Hamburguer[250];

	public boolean checarHamburguer(String nome) {
		boolean retorno = false;
		for (int i = 0; i < this.repositorio.length; i++) {
			if (this.repositorio[i].getNome() == nome) {
				retorno = true;
			}
		}
		return retorno;
	}

	public void inserir(Hamburguer hamburguer) {
		boolean parar = false;

		for (int i = 0; i < this.repositorio.length && !parar; i++) {
			if (this.repositorio[i] == null) {
				this.repositorio[i] = hamburguer;
				parar = true;
			}
		}

	}

	public void remover(String nome) {
		boolean parar = false;

		for (int i = 0; i < this.repositorio.length && !parar; i++) {
			if (this.repositorio[i].getNome() == nome) {
				this.repositorio[i] = null;
				parar = true;
			}
		}

	}

	public Hamburguer procurar(Hamburguer hamburguer) {
		Hamburguer retorno = null;

		for (int i = 0; i < this.repositorio.length; i++) {
			if (this.repositorio[i].getNome() == hamburguer.getNome()) {
				retorno = this.repositorio[i];
			}
		}
		return retorno;

	}

	public void atualizar(String nomeAntigo, String nomeNovo) {

		for (int i = 0; i < this.repositorio.length; i++) {
			if (this.repositorio[i].getNome() == nomeAntigo) {
				this.repositorio[i].setNome(nomeNovo);
			}
		}
	}

}
