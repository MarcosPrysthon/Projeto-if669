package mvpn;
import java.util.*;
import excecoes.*;
public class Teste {

	public static void main(String[] args) throws HamburguerExistenteException, HamburguerInexistenteException {
		Scanner in = new Scanner(System.in);
		
		RepositorioHamburguersLista rep = new RepositorioHamburguersLista();
		NegociosHamburguers negocio = new NegociosHamburguers(rep);

		
		System.out.println("Insira quantos hamburguers voce quiser");
		
		
			Hamburguer hamburguer = new Hamburguer(in.next(), in.nextDouble());
			negocio.inserir(hamburguer);
		
		
		System.out.println("Agora, retire os hamburguers que voce nao quer mais");
		
		
		negocio.remover(in.next());
		
		
		
		System.out.println("Agora, diga qual seu hamburguer favorito");
		
		Hamburguer favorito = negocio.procurar(in.next());
		
		System.out.println(favorito.getNome());
		
		System.out.println("Agora, mude o seu hamburguer favorito para outro");
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
