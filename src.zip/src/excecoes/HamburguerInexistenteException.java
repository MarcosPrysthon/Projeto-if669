package excecoes;

public class HamburguerInexistenteException extends Exception{
	public HamburguerInexistenteException() {
		super("Esse hamburguer n�o existe. Impossivel remove-lo");
	}
	
	
}
